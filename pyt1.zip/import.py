import sys
from PyQt6.QtWidgets import QApplication, QWidget, QLabel,QMessageBox
from PyQt6.uic import loadUi
from PyQt6.QtGui import QPixmap

class MyApp(QWidget):
    def __init__(self):
        super().__init__()
        loadUi("kolor.ui", self)
        self.pushButton.clicked.connect(self.sprawdzCene)
        self.pushButton_2.clicked.connect(self.zatwierdz)

    def sprawdzCene(self):
        cena = ""
        if self.radioButton.isChecked():
            cena = "1zł"
            self.label.setPixmap(QPixmap("pocztowka.png"))
        elif self.radioButton_2.isChecked():
            cena = "1.5zł"
            self.label.setPixmap(QPixmap("list.png"))
        elif self.radioButton_3.isChecked():
            cena = "10zł"
            self.label.setPixmap(QPixmap("paczka.png"))
        else:
            cena = "nie wybrano przesyłki!"
        self.label_2.setText(f"Cena: {cena}")

    def zatwierdz(self):
        ulica = self.lineEdit.text().strip()
        kodPocztowy = self.lineEdit_2.text().strip()
        Miasto = self.lineEdit_3.text().strip()


        if not kodPocztowy.isdigit() and len(kodPocztowy) != 5:
            msg = QMessageBox()
            msg.setText("Nieprawdiłowy zapis kodu Pocztowego i dlugosc")
        elif len(kodPocztowy) != 5:
            msg = QMessageBox()
            msg.setText("Nieprawdiłowa długość kodu pocztowego")
        elif not kodPocztowy.isdigit():
            msg = QMessageBox()
            msg.setText("Nieprawdiłowy zapis kodu Pocztowego")
        else:
            msg = QMessageBox()
            msg.setText("Dane przesyłki zostały wprowadzone")
        
        msg.exec()
            


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyApp()
    window.show()
    sys.exit(app.exec())




