//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

    public static void wyznaczLiczbyPierwsze(boolean[] tablicaLiczb) {
        int n = tablicaLiczb.length - 1;

        for (int i = 2; i <= n; i++) {
            tablicaLiczb[i] = true;
        }

        for (int p = 2; p * p <= n; p++) {
            if (tablicaLiczb[p]) {
                for (int i = p * p; i <= n; i += p) {
                    tablicaLiczb[i] = false;
                }
            }
        }
    }

void main(String[] args) {
        int zakresN = 100;

        boolean[] czyPierwsza = new boolean[zakresN + 1];

        wyznaczLiczbyPierwsze(czyPierwsza);

        System.out.println("Znalezione liczby pierwsze w przedziale od 2 do " + zakresN + ":");

        for (int i = 2; i <= zakresN; i++) {
            if (czyPierwsza[i]) {
                System.out.print(i + ", ");
            }
        }
        System.out.println();
    }

